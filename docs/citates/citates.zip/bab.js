$(function () {
    var $ta = $('<textarea>').prependTo('body').css('width', '100%').css('height', '300px');
    var $citates = $('div.cite');
    var result = '';
    var actualCnt = 0;
    for (var i = 0; i < $citates.size(); i++) {
        var $c = $($citates.get(i));
        var text = $c.children('p').text();
        var pers = $c.children('person').text();
        if (!text || !pers || text.length > 255) {
            continue;//---
        }
        ++actualCnt;
        result += pers + ' | ' + text + '\n';
    }
    $ta.text(result);
    $('<b>').text('Кол-во цитат: ' + actualCnt).insertAfter($ta);
});